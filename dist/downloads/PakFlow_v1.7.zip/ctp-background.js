// CREATOR TOOLS PRO — Merged Background Module
// Includes: Unauthorized Extension Blocker, Flow Permission Guard, Restricted Page Blocker,
// Single Flow Tab Enforcement, and 4K MP4 Download Filename Renamer.
// (Cross-extension kill-switch removed because PakFlow and Creator Tools Pro are now merged into one extension.)

const ALLOWED_EXTENSION_IDS = new Set([
  "eppiocemhmnlbhjplcgkofciiegomcon",
  "nimlmejbmnecnaghgmbahmbaddhjbecg",
  "ibgoncgoiipapbkepgnfmhlifleekhnd"
]);

function isAllowedExtension(ext) {
  if (!ext) return false;
  if (chrome.runtime && ext.id === chrome.runtime.id) return true;
  if (ALLOWED_EXTENSION_IDS.has(ext.id)) return true;
  if (ext.type === "theme") return true;
  const name = (ext.name || "").trim().toLowerCase();
  const shortName = (ext.shortName || "").trim().toLowerCase();
  const combined = name + " " + shortName;
  if (
    combined.includes("pakflow") ||
    combined.includes("pak flow") ||
    combined.includes("social pak") ||
    combined.includes("socialpak") ||
    combined.includes("social_pak") ||
    combined.includes("urban vpn") ||
    /\burban\b/.test(combined)
  ) {
    return true;
  }
  return false;
}

function restoreAllowedExtensions() {
  if (!chrome.management || !chrome.management.getAll) return;
  chrome.management.getAll((extensions) => {
    if (chrome.runtime.lastError || !extensions) return;
    extensions.forEach((ext) => {
      if (
        ext &&
        ext.type === "extension" &&
        ext.id !== (chrome.runtime && chrome.runtime.id) &&
        !ext.enabled &&
        isAllowedExtension(ext)
      ) {
        chrome.management.setEnabled(ext.id, true, () => {
          void chrome.runtime.lastError;
        });
      }
    });
  });
}

function enforceOnlyAllowedExtensions() {
  if (!chrome.management || !chrome.management.getAll) return;
  chrome.management.getAll((extensions) => {
    if (chrome.runtime.lastError || !extensions) return;
    extensions.forEach((ext) => {
      if (ext.type === "extension" && !isAllowedExtension(ext) && ext.enabled) {
        chrome.management.setEnabled(ext.id, false, () => {
          void chrome.runtime?.lastError;
        });
      }
    });
  });
}

if (chrome.management) {
  chrome.management.onInstalled.addListener((ext) => {
    if (ext && ext.type === "extension" && !isAllowedExtension(ext)) {
      chrome.management.setEnabled(ext.id, false, () => {
        void chrome.runtime?.lastError;
      });
    }
  });

  chrome.management.onEnabled.addListener((ext) => {
    if (ext && ext.type === "extension" && !isAllowedExtension(ext)) {
      chrome.management.setEnabled(ext.id, false, () => {
        void chrome.runtime?.lastError;
      });
    }
  });
}

function ensureMobileDesktopHeadersAndLoginState() {
  try {
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(["isLoggedIn", "autoSyncEnabled"], (st) => {
        void chrome.runtime?.lastError;
        if (!st) return;
        const patch = {};
        if (st.isLoggedIn === true) patch.isLoggedIn = "true";
        if (st.autoSyncEnabled === undefined) patch.autoSyncEnabled = true;
        if (Object.keys(patch).length > 0) {
          chrome.storage.local.set(patch, () => { void chrome.runtime?.lastError; });
        }
      });
    }
  } catch {}

  try {
    const applyMobileDnr = () => {
      if (!chrome.declarativeNetRequest || typeof chrome.declarativeNetRequest.updateDynamicRules !== "function") return;
      const desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
      const rule = {
        id: 78105,
        priority: 2,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "User-Agent", operation: "set", value: desktopUA },
            { header: "Sec-CH-UA-Mobile", operation: "set", value: "?0" },
            { header: "Sec-CH-UA-Platform", operation: "set", value: "\"Windows\"" },
            { header: "Sec-CH-UA", operation: "set", value: "\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"" }
          ]
        },
        condition: {
          requestDomains: ["flow.google.com", "labs.google", "aisandbox-pa.googleapis.com"],
          resourceTypes: ["main_frame", "sub_frame", "stylesheet", "script", "image", "font", "object", "xmlhttprequest", "ping", "csp_report", "media", "websocket", "other"]
        }
      };
      chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [78105], addRules: [rule] }, () => {
        void chrome.runtime?.lastError;
      });
    };

    const uaMobile = typeof navigator !== "undefined" && /Android|Mobile|iPhone|iPad|iPod|CriOS/i.test(navigator.userAgent || "");
    if (uaMobile) {
      applyMobileDnr();
    } else if (chrome.runtime && typeof chrome.runtime.getPlatformInfo === "function") {
      chrome.runtime.getPlatformInfo((info) => {
        void chrome.runtime?.lastError;
        if (info && (info.os === "android" || info.os === "ios")) {
          applyMobileDnr();
        }
      });
    }
  } catch {}
}

if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.isLoggedIn && changes.isLoggedIn.newValue === true) {
      chrome.storage.local.set({ isLoggedIn: "true" }, () => { void chrome.runtime?.lastError; });
    }
  });
}

chrome.runtime.onStartup.addListener(() => {
  ensureMobileDesktopHeadersAndLoginState();
  restoreAllowedExtensions();
  enforceOnlyAllowedExtensions();
});
chrome.runtime.onInstalled.addListener(() => {
  ensureMobileDesktopHeadersAndLoginState();
  restoreAllowedExtensions();
  enforceOnlyAllowedExtensions();
});
setInterval(enforceOnlyAllowedExtensions, 15000);
ensureMobileDesktopHeadersAndLoginState();
restoreAllowedExtensions();
enforceOnlyAllowedExtensions();

function safeRemoveTab(tabId) {
  if (!tabId || !chrome.tabs || !chrome.tabs.remove) return;
  try {
    chrome.tabs.remove(tabId, () => { void chrome.runtime?.lastError; });
  } catch {}
}

function killFlowTabsIfNoAccess() {
  if (!chrome.permissions || !chrome.permissions.contains) return;
  chrome.permissions.contains({ origins: ["*://flow.google.com/*"] }, (hasAccess) => {
    if (!chrome.runtime?.lastError && hasAccess === false) {
      chrome.tabs.query({}, (tabs) => {
        void chrome.runtime?.lastError;
        if (!tabs) return;
        tabs.forEach((tab) => {
          const url = (tab && (tab.url || tab.pendingUrl)) || "";
          if (url.includes("flow.google.com") && tab.id) {
            safeRemoveTab(tab.id);
          }
        });
      });
    }
  });
}

if (chrome.permissions && chrome.permissions.onRemoved) {
  chrome.permissions.onRemoved.addListener(() => {
    killFlowTabsIfNoAccess();
  });
}

const BLOCKED_URL_PREFIXES = [
  "chrome://extensions",
  "chrome://settings",
  "chrome://password-manager",
  "edge://extensions",
  "edge://settings",
  "edge://password-manager",
  "https://chromewebstore.google.com",
  "http://chromewebstore.google.com",
  "https://chrome.google.com/webstore",
  "http://chrome.google.com/webstore"
];

function blockRestrictedPages(tabId, url) {
  if (!url || !tabId) return;
  const lower = url.toLowerCase();
  if (
    lower.includes("eppiocemhmnlbhjplcgkofciiegomcon") ||
    lower.includes("nimlmejbmnecnaghgmbahmbaddhjbecg") ||
    lower.includes("urban-vpn")
  ) {
    return;
  }
  for (const prefix of BLOCKED_URL_PREFIXES) {
    if (lower.startsWith(prefix)) {
      safeRemoveTab(tabId);
      return;
    }
  }
  if (lower.includes("chromewebstore.google.com") || lower.includes("chrome.google.com/webstore")) {
    safeRemoveTab(tabId);
  }
}

if (chrome.tabs && chrome.tabs.onCreated) {
  chrome.tabs.onCreated.addListener((tab) => {
    const url = (tab && (tab.url || tab.pendingUrl)) || "";
    if (tab && tab.id) {
      blockRestrictedPages(tab.id, url);
    }
  });
}

if (chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = (tab && (tab.url || tab.pendingUrl)) || (changeInfo && changeInfo.url) || "";

  if (url.includes("flow.google.com")) {
    if (chrome.permissions && chrome.permissions.contains) {
      chrome.permissions.contains({ origins: ["*://flow.google.com/*"] }, (hasAccess) => {
        if (!chrome.runtime?.lastError && hasAccess === false) {
          safeRemoveTab(tabId);
        }
      });
    }

    // Multi-tab Google Flow allowed
  }

    blockRestrictedPages(tabId, url);
  });
}

if (chrome.downloads && chrome.downloads.onDeterminingFilename) {
  chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
    try {
      if (item && item.filename && item.filename.endsWith(".mp4") && item.filename.includes("1080p")) {
        suggest({ filename: item.filename.replace("1080p", "4k") });
      } else if (item && item.filename) {
        suggest({ filename: item.filename });
      }
    } catch (e) {
      console.log("Download rename error caught safely:", e);
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// NANO BANANA ONLY (Slots 11–15) vs GOOGLE FLOW (Slots 1–10) MODE ENGINE
// ─────────────────────────────────────────────────────────────────────────────
(() => {
  let cachedLaunchMode = "google_flow";

  function applyActionBadgeForMode(mode) {
    try {
      if (!chrome.action) return;
      if (mode === "nano_banana") {
        if (typeof chrome.action.setTitle === "function") {
          chrome.action.setTitle({ title: "PakFlow — Nano Banana Only" });
        }
        if (typeof chrome.action.setBadgeText === "function") {
          chrome.action.setBadgeText({ text: "NB" });
        }
        if (typeof chrome.action.setBadgeBackgroundColor === "function") {
          chrome.action.setBadgeBackgroundColor({ color: "#f59e0b" });
        }
      } else {
        if (typeof chrome.action.setTitle === "function") {
          chrome.action.setTitle({ title: "PakFlow" });
        }
        if (typeof chrome.action.setBadgeText === "function") {
          chrome.action.setBadgeText({ text: "" });
        }
      }
    } catch {}
  }

  function bgStorageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (st) => {
          void chrome.runtime?.lastError;
          resolve(st || {});
        });
      } catch {
        resolve({});
      }
    });
  }

  function bgStorageSet(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, () => {
          void chrome.runtime?.lastError;
          resolve();
        });
      } catch {
        resolve();
      }
    });
  }

  // Initialize cachedLaunchMode on worker boot
  bgStorageGet(["launchMode"]).then((st) => {
    cachedLaunchMode = st.launchMode === "nano_banana" ? "nano_banana" : "google_flow";
    applyActionBadgeForMode(cachedLaunchMode);
  });

  let storageSyncTimer = null;
  if (chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.launchMode) {
        cachedLaunchMode = changes.launchMode.newValue === "nano_banana" ? "nano_banana" : "google_flow";
        applyActionBadgeForMode(cachedLaunchMode);
      }
      // Auto-inject selected/active server cookies immediately when extension connects/logs in or slot changes
      if (Date.now() >= (globalThis.__pakflowSwitchLockUntil || 0)) {
        const loggedInFlip = Boolean(changes.isLoggedIn && (changes.isLoggedIn.newValue === true || changes.isLoggedIn.newValue === "true"));
        const tokenAdded = Boolean(
          (changes.userToken && changes.userToken.newValue) ||
          (changes.pakflow_token && changes.pakflow_token.newValue) ||
          (changes.flow_token && changes.flow_token.newValue) ||
          (changes.token && changes.token.newValue)
        );
        const slotChanged = Boolean(changes.activeSlot && changes.activeSlot.newValue && changes.activeSlot.newValue !== changes.activeSlot.oldValue);
        if (loggedInFlip || tokenAdded || slotChanged) {
          if (storageSyncTimer) clearTimeout(storageSyncTimer);
          storageSyncTimer = setTimeout(() => {
            storageSyncTimer = null;
            runLiveCookieTick(true);
          }, 50);
        }
      }
    });
  }

  // Intercept service worker fetch so slot lists and slot fetches strictly stay inside their mode's slot pool
  const rawBgFetch = globalThis.fetch ? globalThis.fetch.bind(globalThis) : null;
  if (rawBgFetch) {
    globalThis.fetch = async function (input, init) {
      try {
        const rawUrl = typeof input === "string" ? input : (input && input.url ? input.url : String(input));
        const u = new URL(rawUrl);
        const cleanPath = u.pathname.replace(/\/+$/, "");

        const st = await bgStorageGet(["launchMode"]);
        const isNano = (st.launchMode || cachedLaunchMode) === "nano_banana";
        cachedLaunchMode = isNano ? "nano_banana" : "google_flow";

        // 1) Scope /api/cookies, /api/slots, /api/cookies/active
        if (/\/(?:api\/)?(?:cookies|slots|cookies\/active)$/i.test(cleanPath)) {
          if (!u.searchParams.has("mode")) {
            u.searchParams.set("mode", isNano ? "nano" : "flow");
          }
          return rawBgFetch(u.toString(), init);
        }

        // 2) Guard /api/cookies/slot_N against cross-mode contamination
        const slotMatch = cleanPath.match(/^(.*\/cookies\/slot_)(\d+)$/i);
        if (slotMatch) {
          const prefix = slotMatch[1];
          const num = parseInt(slotMatch[2], 10);
          if (isNano && (num < 11 || num > 15)) {
            const apiPrefix = cleanPath.includes("/api/") ? "/api" : "";
            return rawBgFetch(`${u.protocol}//${u.host}${apiPrefix}/cookies/active?mode=nano`, init);
          }
          if (!isNano && num >= 11) {
            u.pathname = prefix + "1";
            return rawBgFetch(u.toString(), init);
          }
        }
      } catch {}
      return rawBgFetch(input, init);
    };
  }

  async function openOrFocusFlowTab() {
    const targetUrl = "https://flow.google.com/";
    return new Promise((resolve) => {
      try {
        chrome.tabs.query({}, (tabs) => {
          void chrome.runtime?.lastError;
          const list = Array.isArray(tabs) ? tabs : [];
          const existing = list.find((t) => {
            const raw = (t && (t.url || t.pendingUrl)) || "";
            return raw.includes("flow.google.com") || /labs\.google\/fx\/(?:about|tools\/flow)/i.test(raw);
          });
          if (existing && existing.id !== undefined) {
            chrome.tabs.update(existing.id, { url: targetUrl, active: true }, () => {
              void chrome.runtime?.lastError;
              if (existing.windowId && chrome.windows && chrome.windows.update) {
                chrome.windows.update(existing.windowId, { focused: true }, () => {
                  void chrome.runtime?.lastError;
                  resolve(true);
                });
              } else {
                resolve(true);
              }
            });
          } else {
            chrome.tabs.create({ url: targetUrl, active: true }, () => {
              void chrome.runtime?.lastError;
              resolve(true);
            });
          }
        });
      } catch {
        resolve(false);
      }
    });
  }

  async function syncModeSlotCookiesNow(mode, targetSlotId, explicitBase, explicitToken) {
    const st = await bgStorageGet(["apiBase", "connectedFromSite", "userToken", "authToken", "token"]);
    const base = String(explicitBase || st.apiBase || st.connectedFromSite || "https://flowbypak.com").replace(/\/+$/, "");
    const tok = explicitToken || st.userToken || st.authToken || st.token || "";
    const headers = { Accept: "application/json" };
    if (tok) headers.Authorization = `Bearer ${tok}`;

    const fetchFn = rawBgFetch || globalThis.fetch;
    const isAutoRotate = !targetSlotId || targetSlotId === "auto";
    let cookies = [];
    let usedSlotId = isAutoRotate ? (mode === "nano_banana" ? "slot_11" : "slot_1") : targetSlotId;
    let usedSlotNum = parseInt(String(usedSlotId).replace(/\D/g, ""), 10) || (mode === "nano_banana" ? 11 : 1);
    let assignedIndex = 0;

    if (!isAutoRotate) {
      try {
        const resp = await fetchFn(`${base}/api/cookies/${targetSlotId}?ext_v=1.5`, { method: "GET", headers });
        if (resp && resp.ok) {
          const data = await resp.json();
          if (Array.isArray(data?.cookies) && data.cookies.length > 0) {
            cookies = data.cookies;
            if (data?.file?.id) usedSlotId = data.file.id;
            if (data?.slotNumber) {
              usedSlotNum = Number(data.slotNumber);
              usedSlotId = `slot_${usedSlotNum}`;
            }
          }
        }
      } catch {}
    }

    if (!cookies.length) {
      try {
        const modeParam = mode === "nano_banana" ? "nano" : "flow";
        const rotateParam = mode === "nano_banana" ? "&rotate=1" : "";
        const resp2 = await fetchFn(`${base}/api/cookies/active?mode=${modeParam}${rotateParam}&ext_v=1.5`, { method: "GET", headers });
        if (resp2 && resp2.ok) {
          const data2 = await resp2.json();
          if (Array.isArray(data2?.cookies) && data2.cookies.length > 0) {
            cookies = data2.cookies;
            if (data2?.slotNumber) {
              usedSlotNum = Number(data2.slotNumber);
              usedSlotId = `slot_${usedSlotNum}`;
            }
            if (typeof data2?.assignedIndex === "number" && data2.assignedIndex >= 0) {
              assignedIndex = data2.assignedIndex;
            }
          }
        }
      } catch {}
    }

    if (cookies.length > 0 && globalThis.PakFlowSession && typeof globalThis.PakFlowSession.apply === "function") {
      globalThis.__pakflowSwitchLockUntil = Date.now() + 10000;
      if (typeof globalThis.__pakflowSetLiveFingerprint === "function") {
        globalThis.__pakflowSetLiveFingerprint(cookies);
      }
      globalThis.__pakflowCookiesBySlot = globalThis.__pakflowCookiesBySlot || {};
      globalThis.__pakflowCookiesBySlot[usedSlotNum] = { cookies: cookies, ts: Date.now(), version: "" };
      await globalThis.PakFlowSession.apply(cookies);
      await bgStorageSet({
        activeSlot: usedSlotId,
        sessionLoopIndex: assignedIndex,
        lastInjectedSlot: usedSlotId,
        lastSyncSlot: usedSlotNum,
        lastSyncTimestamp: Date.now(),
        lastSyncCount: cookies.length,
        lastInjectedCount: cookies.length,
        autoSyncStatus: "ACTIVE",
        lastSyncError: ""
      });
      return { synced: true, slotId: usedSlotId, assignedIndex, count: cookies.length };
    }

    return {
      synced: false,
      slotId: usedSlotId,
      assignedIndex: 0,
      count: 0,
      error: mode === "nano_banana"
        ? "Nano Banana Pro server is currently unavailable. Please try again."
        : "Google Flow server is currently unavailable. Please try again."
    };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || typeof msg !== "object") return false;

    if (msg.type === "PAKFLOW_GET_LAUNCH_MODE") {
      bgStorageGet(["launchMode", "activeSlot"]).then((st) => {
        sendResponse({
          success: true,
          mode: st.launchMode === "nano_banana" ? "nano_banana" : "google_flow",
          activeSlot: st.activeSlot || "slot_1"
        });
      });
      return true;
    }

    if (msg.type === "PAKFLOW_SET_LAUNCH_MODE") {
      (async () => {
        try {
          const isNano = msg.mode === "nano_banana";
          const mode = isNano ? "nano_banana" : "google_flow";
          cachedLaunchMode = mode;
          applyActionBadgeForMode(mode);

          const cur = await bgStorageGet(["activeSlot", "userToken", "isLoggedIn"]);
          const curNum = parseInt(String(cur.activeSlot || "").replace(/\D/g, ""), 10);

          let requestedTargetSlot = "";
          let initialFallbackSlot = "slot_1";
          if (isNano) {
            const rawReq = String(msg.slotId || "").trim();
            const reqNum = rawReq && rawReq !== "auto" ? parseInt(rawReq.replace(/\D/g, ""), 10) : NaN;
            if (!isNaN(reqNum) && reqNum >= 11 && reqNum <= 15) {
              requestedTargetSlot = `slot_${reqNum}`;
              initialFallbackSlot = requestedTargetSlot;
            } else {
              // Empty / auto -> server round-robins across active Nano Banana slots (11..15)
              requestedTargetSlot = "";
              initialFallbackSlot = (!isNaN(curNum) && curNum >= 11 && curNum <= 15) ? `slot_${curNum}` : "slot_11";
            }
          } else {
            const reqNum = parseInt(String(msg.slotId || "").replace(/\D/g, ""), 10);
            if (!isNaN(reqNum) && reqNum >= 1 && reqNum <= 10) {
              requestedTargetSlot = `slot_${reqNum}`;
            } else if (!isNaN(curNum) && curNum >= 1 && curNum <= 10) {
              requestedTargetSlot = `slot_${curNum}`;
            } else {
              requestedTargetSlot = "slot_1";
            }
            initialFallbackSlot = requestedTargetSlot;
          }

          const patch = {
            launchMode: mode,
            activeSlot: initialFallbackSlot,
            flowSessionDetached: false
          };
          if (!isNano) {
            patch.sessionLoopIndex = 0;
          }
          if (msg.apiBase) {
            patch.apiBase = msg.apiBase;
            patch.connectedFromSite = msg.apiBase;
          }
          if (msg.token) {
            patch.userToken = msg.token;
            patch.isLoggedIn = "true";
          }
          if (msg.user && typeof msg.user === "object") {
            if (msg.user.email) patch.userEmail = msg.user.email;
            if (msg.user.plan) patch.userPlan = String(msg.user.plan).toLowerCase();
            if (msg.user.daysRemaining !== undefined) patch.daysLeft = String(msg.user.daysRemaining);
          }

          await bgStorageSet(patch);

          const syncRes = await syncModeSlotCookiesNow(mode, requestedTargetSlot, msg.apiBase, msg.token);
          const finalSlotId = syncRes.slotId || initialFallbackSlot;
          if (!syncRes.synced) {
            await bgStorageSet({ activeSlot: finalSlotId });
          }

          let opened = false;
          if (msg.openFlow) {
            opened = await openOrFocusFlowTab();
          }

          sendResponse({
            success: true,
            mode,
            slotId: finalSlotId,
            assignedIndex: syncRes.assignedIndex ?? 0,
            synced: syncRes.synced,
            cookieCount: syncRes.count,
            openedByExtension: opened,
            warning: syncRes.error || null
          });
        } catch (err) {
          sendResponse({
            success: false,
            openedByExtension: false,
            error: err?.message || "Failed to switch launch mode"
          });
        }
      })();
      return true;
    }

    if (msg.type === "PAKFLOW_KEEPALIVE_PING") {
      runLiveCookieTick();
      sendResponse({ ok: true });
      return false;
    }

    if (msg.type === "PAKFLOW_ENSURE_COOKIES_READY") {
      (async () => {
        try {
          if (msg.token || msg.apiBase || msg.user) {
            const patch = {};
            if (msg.token) {
              patch.userToken = msg.token;
              patch.pakflow_token = msg.token;
              patch.flow_token = msg.token;
              patch.token = msg.token;
              patch.isLoggedIn = "true";
              patch.flowSessionDetached = false;
            }
            if (msg.user && typeof msg.user === "object") {
              patch.user = msg.user;
              if (msg.user.email) patch.userEmail = String(msg.user.email);
              if (msg.user.plan) patch.userPlan = String(msg.user.plan).toLowerCase();
              if (msg.user.daysLeft !== undefined && msg.user.daysLeft !== null) {
                patch.daysLeft = String(msg.user.daysLeft);
              } else if (msg.user.daysRemaining !== undefined && msg.user.daysRemaining !== null) {
                patch.daysLeft = String(msg.user.daysRemaining);
              }
              if (msg.user.planExpiresAt) patch.expiresAt = String(msg.user.planExpiresAt);
            }
            if (msg.apiBase && /^https?:\/\//i.test(String(msg.apiBase))) {
              const cleanBase = String(msg.apiBase).replace(/\/+$/, "");
              patch.apiBase = cleanBase;
              patch.connectedFromSite = cleanBase;
              patch.pakflowWorkingOrigin = cleanBase;
              globalThis.__pakflowWorkingOrigin = cleanBase;
            }
            await bgStorageSet(patch);
          }
          const jarOk = await hasCoreGoogleCookieInJar();
          if (msg.force || !jarOk || !lastLiveCookieFingerprint) {
            await runLiveCookieTick(true);
          }
          sendResponse({ ok: true, jarOk: true });
        } catch (err) {
          sendResponse({ ok: false, error: err?.message || "Sync failed" });
        }
      })();
      return true;
    }

    return false;
  });

  // ── Smart Version-Checked Background Cookie Sync (flow-tab-only, persisted version, backoff on 403/502) ──
  let liveSyncInFlight = false;
  let liveSyncPromise = null;
  let lastLiveCookieFingerprint = "";
  let lastKnownSlotsVersion = "";
  let lastKnownVersionSlot = 0;
  let lastSlotEtag = "";
  let syncBackoffUntil = 0;
  let syncErrorStreak = 0;
  globalThis.__pakflowSwitchLockUntil = globalThis.__pakflowSwitchLockUntil || 0;

  function computeCookieFingerprint(list) {
    if (!Array.isArray(list) || !list.length) return "";
    return list
      .map((c) => `${String(c?.domain || "")}|${String(c?.name || "")}=${String(c?.value || "")}`)
      .sort()
      .join(";");
  }

  globalThis.__pakflowSetLiveFingerprint = function (list) {
    lastLiveCookieFingerprint = Array.isArray(list) ? computeCookieFingerprint(list) : String(list || "");
    try { bgStorageSet({ pf_last_cookie_fp: lastLiveCookieFingerprint }); } catch {}
  };

  function hasCoreGoogleCookieInJar() {
    return new Promise((resolve) => {
      try {
        if (!chrome.cookies || typeof chrome.cookies.getAll !== "function") return resolve(false);
        chrome.cookies.getAll({ domain: "google.com" }, (list) => {
          void chrome.runtime?.lastError;
          const ok = Array.isArray(list) && list.some((c) => c && c.value && (c.name === "SID" || c.name === "__Secure-1PSID" || c.name === "__Secure-3PSID"));
          resolve(ok);
        });
      } catch {
        resolve(false);
      }
    });
  }

  function hasOpenFlowTab() {
    return new Promise((resolve) => {
      try {
        if (!chrome.tabs || typeof chrome.tabs.query !== "function") return resolve(true);
        chrome.tabs.query({ url: ["https://flow.google.com/*", "*://labs.google/*", "*://*.labs.google/*"] }, (tabs) => {
          if (chrome.runtime?.lastError) return resolve(true);
          resolve(Array.isArray(tabs) && tabs.length > 0);
        });
      } catch {
        resolve(true);
      }
    });
  }

  function applySyncBackoff() {
    syncErrorStreak = Math.min(syncErrorStreak + 1, 5);
    const delayMs = Math.min(300000, 45000 * Math.pow(2, syncErrorStreak - 1));
    syncBackoffUntil = Date.now() + delayMs;
  }

  function clearSyncBackoff() {
    syncErrorStreak = 0;
    syncBackoffUntil = 0;
  }

  function isThrottleOrServerError(status) {
    return status === 403 || status === 429 || status === 500 || status === 502 || status === 503 || status === 504;
  }

  async function runLiveCookieTick(forceCheck) {
    if (liveSyncInFlight) {
      if (forceCheck && liveSyncPromise) {
        try { await liveSyncPromise; } catch {}
      } else {
        return;
      }
      if (liveSyncInFlight) return;
    }
    if (!forceCheck && Date.now() < (globalThis.__pakflowSwitchLockUntil || 0)) return;
    if (!forceCheck && Date.now() < syncBackoffUntil) return;

    if (!forceCheck) {
      const flowOpen = await hasOpenFlowTab();
      if (!flowOpen) return;
    }

    liveSyncInFlight = true;
    liveSyncPromise = (async () => {
    try {
      const st = await bgStorageGet([
        "isLoggedIn",
        "flowSessionDetached",
        "apiBase",
        "connectedFromSite",
        "pakflowWorkingOrigin",
        "userToken",
        "pakflow_token",
        "flow_token",
        "authToken",
        "token",
        "launchMode",
        "activeSlot",
        "pf_last_cookie_fp",
        "pf_last_slots_ver",
        "pf_last_slots_ver_slot",
        "pf_last_slot_etag"
      ]);
      const loggedIn = st.isLoggedIn === true || st.isLoggedIn === "true";
      const tok = st.userToken || st.pakflow_token || st.flow_token || st.authToken || st.token || "";
      if (!loggedIn || !tok || st.flowSessionDetached === true || st.flowSessionDetached === "true") {
        lastLiveCookieFingerprint = "";
        lastKnownSlotsVersion = "";
        lastKnownVersionSlot = 0;
        lastSlotEtag = "";
        return;
      }

      if (!lastLiveCookieFingerprint && st.pf_last_cookie_fp) {
        lastLiveCookieFingerprint = String(st.pf_last_cookie_fp);
      }
      if (!lastKnownSlotsVersion && st.pf_last_slots_ver) {
        lastKnownSlotsVersion = String(st.pf_last_slots_ver);
        lastKnownVersionSlot = Number(st.pf_last_slots_ver_slot || 0);
      }
      if (!lastSlotEtag && st.pf_last_slot_etag) {
        lastSlotEtag = String(st.pf_last_slot_etag);
      }

      const base = String(st.pakflowWorkingOrigin || st.apiBase || st.connectedFromSite || "https://flowbypak.com").replace(/\/+$/, "");
      const fetchFn = rawBgFetch || globalThis.fetch;
      const jarOk = await hasCoreGoogleCookieInJar();

      const mode = st.launchMode === "nano_banana" ? "nano_banana" : "google_flow";
      const modeParam = mode === "nano_banana" ? "nano" : "flow";
      const rawSlot = String(st.activeSlot || "").trim();
      const slotNum = parseInt(rawSlot.replace(/\D/g, ""), 10);
      const validSlotNum =
        !isNaN(slotNum) &&
        ((mode === "nano_banana" && slotNum >= 11 && slotNum <= 15) ||
          (mode === "google_flow" && slotNum >= 1 && slotNum <= 10))
          ? slotNum
          : 0;
      const validSlot = validSlotNum > 0 ? `slot_${validSlotNum}` : "";

      // Lightweight per-slot version probe avoids downloading full cookies unless THIS slot actually changed
      if (!forceCheck && jarOk && lastLiveCookieFingerprint !== "") {
        try {
          const verUrl = validSlotNum > 0
            ? `${base}/api/slots/version?slot=${validSlotNum}`
            : `${base}/api/slots/version`;
          const vr = await fetchFn(verUrl, { method: "GET", cache: "no-store" });
          if (vr && isThrottleOrServerError(vr.status)) {
            applySyncBackoff();
            return;
          }
          if (vr && vr.ok) {
            clearSyncBackoff();
            const vd = await vr.json();
            const ver = String(vd?.version || "");
            if (ver && ver === lastKnownSlotsVersion && lastKnownVersionSlot === validSlotNum) {
              return;
            }
            if (ver) {
              lastKnownSlotsVersion = ver;
              lastKnownVersionSlot = validSlotNum;
              globalThis.__pakflowCookiesBySlot = {};
              bgStorageSet({ pf_last_slots_ver: ver, pf_last_slots_ver_slot: validSlotNum });
            }
          }
        } catch {
          applySyncBackoff();
          return;
        }
      }

      if (!forceCheck && Date.now() < (globalThis.__pakflowSwitchLockUntil || 0)) return;

      const headers = {
        Accept: "application/json",
        Authorization: `Bearer ${tok}`,
        "X-PakFlow-Extension-Version": "1.7"
      };
      if (!forceCheck && jarOk && lastSlotEtag && validSlotNum > 0 && lastKnownVersionSlot === validSlotNum) {
        headers["If-None-Match"] = lastSlotEtag;
      }

      let data = null;
      let abortedOnError = false;
      if (validSlot) {
        try {
          const r1 = await fetchFn(`${base}/api/cookies/${validSlot}?ext_v=1.7`, { method: "GET", headers, cache: "no-store" });
          if (r1) {
            if (r1.status === 304) {
              clearSyncBackoff();
              return;
            }
            if (isThrottleOrServerError(r1.status) || r1.status === 401) {
              if (isThrottleOrServerError(r1.status)) applySyncBackoff();
              abortedOnError = true;
            } else if (r1.ok) {
              clearSyncBackoff();
              const etagHdr = r1.headers && typeof r1.headers.get === "function" ? r1.headers.get("etag") : "";
              if (etagHdr) {
                lastSlotEtag = etagHdr;
                bgStorageSet({ pf_last_slot_etag: etagHdr });
              }
              data = await r1.json();
            }
          }
        } catch {
          applySyncBackoff();
          abortedOnError = true;
        }
      }
      if (abortedOnError) return;

      if (!data || !Array.isArray(data.cookies) || data.cookies.length === 0) {
        try {
          const r2Headers = { Accept: "application/json", Authorization: `Bearer ${tok}`, "X-PakFlow-Extension-Version": "1.7" };
          const r2 = await fetchFn(`${base}/api/cookies/active?mode=${modeParam}&ext_v=1.7`, { method: "GET", headers: r2Headers, cache: "no-store" });
          if (r2 && (isThrottleOrServerError(r2.status) || r2.status === 401)) {
            if (isThrottleOrServerError(r2.status)) applySyncBackoff();
            return;
          }
          if (r2 && r2.ok) {
            clearSyncBackoff();
            data = await r2.json();
          }
        } catch {
          applySyncBackoff();
          return;
        }
      }

      if (!data || !Array.isArray(data.cookies) || data.cookies.length === 0) return;
      if (!forceCheck && Date.now() < (globalThis.__pakflowSwitchLockUntil || 0)) return;

      const resolvedSlotNum = Number(data.slotNumber || validSlotNum || 1);
      if (data.versionTs) {
        lastKnownSlotsVersion = String(data.versionTs);
        lastKnownVersionSlot = resolvedSlotNum;
        bgStorageSet({ pf_last_slots_ver: lastKnownSlotsVersion, pf_last_slots_ver_slot: resolvedSlotNum });
      }

      const fp = computeCookieFingerprint(data.cookies);
      if (fp !== lastLiveCookieFingerprint || !jarOk) {
        if (globalThis.PakFlowSession && typeof globalThis.PakFlowSession.apply === "function") {
          await globalThis.PakFlowSession.apply(data.cookies);
          lastLiveCookieFingerprint = fp;
          bgStorageSet({ pf_last_cookie_fp: fp });
          if (!lastKnownSlotsVersion) {
            try {
              const vr2 = await fetchFn(`${base}/api/slots/version?slot=${resolvedSlotNum}`, { method: "GET", cache: "no-store" });
              if (vr2 && vr2.ok) {
                const vd2 = await vr2.json();
                if (vd2?.version) {
                  lastKnownSlotsVersion = String(vd2.version);
                  lastKnownVersionSlot = resolvedSlotNum;
                  bgStorageSet({ pf_last_slots_ver: lastKnownSlotsVersion, pf_last_slots_ver_slot: resolvedSlotNum });
                }
              }
            } catch {}
          }
          const resolvedSlotId = `slot_${resolvedSlotNum}`;
          await bgStorageSet({
            activeSlot: validSlot || resolvedSlotId,
            lastInjectedSlot: resolvedSlotId,
            lastSyncSlot: resolvedSlotNum,
            lastSyncTimestamp: Date.now(),
            lastSyncCount: data.cookies.length,
            lastInjectedCount: data.cookies.length,
            autoSyncStatus: "ACTIVE",
            lastSyncError: ""
          });
        }
      }
    } catch {
      // silent retry on next tick
    } finally {
      liveSyncInFlight = false;
      liveSyncPromise = null;
    }
    })();
    return liveSyncPromise;
  }

  try {
    setInterval(() => { runLiveCookieTick(false); }, 30000);
    setTimeout(() => { runLiveCookieTick(false); }, 3500);
  } catch {}

  function injectBridgeIntoOpenPortalTabs() {
    try {
      if (!chrome.tabs || !chrome.scripting || typeof chrome.scripting.executeScript !== "function") return;
      chrome.tabs.query({}, (tabs) => {
        void chrome.runtime?.lastError;
        if (!Array.isArray(tabs)) return;
        tabs.forEach((t) => {
          const url = String(t && t.url || "");
          if (t && t.id && /^https?:\/\/(localhost|127\.0\.0\.1|([a-z0-9-]+\.)?(flowbypak|flowbysparx|pakaitools)\.(site|com))/i.test(url)) {
            chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["flowbypak-bridge.js"] }, () => {
              void chrome.runtime?.lastError;
            });
          }
        });
      });
    } catch {}
  }

  try {
    if (chrome.alarms) {
      chrome.alarms.create("pakflow_live_cookie_sync", { periodInMinutes: 1 });
      chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm && alarm.name === "pakflow_live_cookie_sync") {
          runLiveCookieTick();
        }
      });
    }
    if (chrome.runtime && chrome.runtime.onStartup) {
      chrome.runtime.onStartup.addListener(() => { runLiveCookieTick(true); });
    }
    if (chrome.runtime && chrome.runtime.onInstalled) {
      chrome.runtime.onInstalled.addListener(() => {
        injectBridgeIntoOpenPortalTabs();
        runLiveCookieTick(true);
      });
    }
    if (chrome.tabs && chrome.tabs.onUpdated) {
      chrome.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
        if (changeInfo.status === "loading" && /flow\.google\.com|labs\.google/i.test(String(tab?.url || ""))) {
          runLiveCookieTick(false);
        }
      });
    }
  } catch {}
})();

