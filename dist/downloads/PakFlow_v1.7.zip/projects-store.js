/* Project history is partitioned by IP and selected server. Existing records
 * keep their slot, timestamps and metadata; no migration deletes old projects. */
(() => {
  if (globalThis.__pfErrorShieldInstalled) return;
  globalThis.__pfErrorShieldInstalled = true;
  try {
    const noop = () => {};
    const dbg = typeof console !== 'undefined' && typeof console.debug === 'function' ? console.debug.bind(console) : noop;
    if (typeof console !== 'undefined') {
      console.error = (...args) => { try { dbg(...args); } catch {} };
      console.warn = (...args) => { try { dbg(...args); } catch {} };
    }
  } catch {}
  try {
    if (typeof globalThis.addEventListener === 'function') {
      globalThis.addEventListener('error', (e) => { try { e.preventDefault(); } catch {} });
      globalThis.addEventListener('unhandledrejection', (e) => { try { e.preventDefault(); } catch {} });
    }
  } catch {}
})();
globalThis.PakFlowProjects = (() => {
  let pending = Promise.resolve();
  const normalize = value => typeof value === 'string' && value.trim() && value !== 'active' ? value.trim() : 'slot_1';
  const selected = state => typeof state.activeSlot === 'string' && state.activeSlot.trim() && state.activeSlot !== 'active'
    ? normalize(state.activeSlot) : 'slot_' + ((Number.isInteger(state.sessionLoopIndex) && state.sessionLoopIndex >= 0 ? state.sessionLoopIndex : 0) + 1);
  const belongs = (project, slot) => normalize(project.slot) === slot;
  const sorted = list => [...list].sort((a,b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
  function run(action) {
    const result = pending.then(action);
    pending = result.catch(() => {});
    return result;
  }
  async function context(resolveIp) {
    const ip = await resolveIp();
    const state = await chrome.storage.local.get(['myProjectsByIp', 'myProjectServerOwnersByIp', 'activeSlot', 'sessionLoopIndex']);
    const byIp = state.myProjectsByIp && typeof state.myProjectsByIp === 'object' ? {...state.myProjectsByIp} : {};
    const all = Array.isArray(byIp[ip]) ? [...byIp[ip]] : [];
    const ownersByIp = state.myProjectServerOwnersByIp && typeof state.myProjectServerOwnersByIp === 'object' ? {...state.myProjectServerOwnersByIp} : {};
    const owners = {...ownersByIp[ip]};
    // A Flow project ID identifies one project, regardless of the selected
    // server. Infer older records' owner from their earliest saved copy.
    for (const project of [...all].sort((a,b) => (a.createdAt || a.updatedAt || 0) - (b.createdAt || b.updatedAt || 0))) {
      const id = String(project.id || '').toLowerCase();
      if (id && !Object.hasOwn(owners, id)) owners[id] = normalize(project.slot);
    }
    ownersByIp[ip] = owners;
    return {ip, byIp, all, ownersByIp, owners, slot: selected(state)};
  }
  function response(ctx) {
    const seen = new Set();
    const projects = sorted(ctx.all).filter(p => {
      const id = String(p.id || '').toLowerCase();
      if (!belongs(p, ctx.slot) || ctx.owners[id] !== ctx.slot || seen.has(id)) return false;
      seen.add(id); return true;
    });
    return {ip: ctx.ip, activeSlot: ctx.slot, projects, ownedIds: projects.map(p => p.id)};
  }
  async function persist(ctx) {
    ctx.byIp[ctx.ip] = ctx.all;
    // The selected slot may change while the write is pending. Cache ownership
    // for the latest slot, so an earlier request cannot restore another server.
    const latest = await chrome.storage.local.get(['activeSlot', 'sessionLoopIndex']);
    const cacheSlot = selected(latest);
    await chrome.storage.local.set({myProjectsByIp: ctx.byIp, myProjectServerOwnersByIp: ctx.ownersByIp, myProjectsCurrentIp: ctx.ip,
      myProjectsOwnedIds: response({...ctx,slot:cacheSlot}).ownedIds});
    return response(ctx);
  }
  return {
    list(resolveIp) { return run(async () => {
      const ctx = await context(resolveIp);
      await chrome.storage.local.set({myProjectServerOwnersByIp:ctx.ownersByIp});
      return response(ctx);
    }); },
    save(resolveIp, input = {}) { return run(async () => {
      const ctx = await context(resolveIp);
      const match = String(input.url || '').match(/\/project\/([^/?#]+)/i);
      const id = String(input.id || match?.[1] || '').toLowerCase();
      if (!id) return response(ctx);
      // An explicitly attributed project may finish saving after a server switch.
      const target = input.slot ? normalize(input.slot) : ctx.slot;
      // Old tabs keep reporting their current URL after switching servers.
      // Reject reattribution instead of cloning the same ID into the new server.
      if (Object.hasOwn(ctx.owners,id) && ctx.owners[id] !== target) return response(ctx);
      ctx.owners[id] = target;
      const index = ctx.all.findIndex(p => p.id === id && belongs(p, target));
      const previous = index >= 0 ? ctx.all[index] : null;
      const title = String(input.title || '').trim();
      const prompt = String(input.prompt || '').trim().slice(0, 180);
      const generic = !title || /^(?:flow|google\s*flow|new\s*project)$/i.test(title) || /^flow\s*-\s*google/i.test(title);
      const number = ctx.all.filter(p => belongs(p, target)).length + 1;
      const now = Date.now();
      const project = {...previous, id, url: 'https://flow.google.com/project/' + id,
        slot: target, ip: ctx.ip, createdAt: previous?.createdAt || now, updatedAt: now};
      if (input.customTitle && title) { project.title = title; project.customTitle = true; }
      else if (!previous?.customTitle && !generic) project.title = title;
      if (!project.title) project.title = prompt ? prompt.slice(0, 60) : 'Project #' + number;
      if (prompt) project.prompt = prompt;
      if (project.customTitle === undefined) project.customTitle = false;
      if (index >= 0) ctx.all[index] = project; else ctx.all.unshift(project);
      return persist(ctx);
    }); },
    rename(resolveIp, id, title) { return run(async () => {
      const ctx = await context(resolveIp);
      id = String(id || '').toLowerCase(); title = String(title || '').trim();
      if (ctx.owners[id] !== ctx.slot) return response(ctx);
      const index = ctx.all.findIndex(p => p.id === id && belongs(p, ctx.slot));
      if (index < 0 || !title) return response(ctx);
      ctx.all[index] = {...ctx.all[index], title, customTitle: true, updatedAt: Date.now()};
      return persist(ctx);
    }); },
    remove(resolveIp, id) { return run(async () => {
      const ctx = await context(resolveIp); id = String(id || '').toLowerCase();
      if (ctx.owners[id] !== ctx.slot) return response(ctx);
      ctx.all = ctx.all.filter(p => p.id !== id || !belongs(p, ctx.slot));
      return persist(ctx);
    }); }
  };
})();
